<?php 
// admin related functions
