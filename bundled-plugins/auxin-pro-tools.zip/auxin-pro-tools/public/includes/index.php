<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
    die('No Naughty Business Please !');
}

include 'class-auxpro-frontend-assets.php';
include 'templates-post.php';
