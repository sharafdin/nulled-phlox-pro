export const arr_examples = [
  {
    'img':'assets/sampledata_img/sample--skin-wave-simple.jpg',
    'name':'sample--skin-wave-simple',
    'label':'Skin Wave Simple',
  },
  {
    'img':'assets/sampledata_img/sample--boxed-inside.jpg',
    'name':'sample--boxed-inside',
    'label':'Wave Boxed Inside',
  },
  {
    'img':'assets/sampledata_img/sample--skin-pro-simple.jpg',
    'name':'sample--skin-pro-simple',
    'label':'Skin Pro Simple',
  },
  {
    'img':'assets/sampledata_img/sample--skin-justthumbandbutton.jpg',
    'name':'sample--skin-justthumbandbutton',
    'label':'Skin Just Thumb and Button',
  },
];