'use strict';


document.addEventListener("DOMContentLoaded", function () {
  var nodes = document.querySelector('.zoomsounds-embed-con');
  document.body.append(nodes);
});