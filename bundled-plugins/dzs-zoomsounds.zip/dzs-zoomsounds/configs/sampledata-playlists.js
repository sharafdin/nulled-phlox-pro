export const sampleDataPlaylists = [
  {
    'img':'assets/sampledata_img/sample-playlist--playlist-simple.jpg',
    'name':'playlist-simple',
    'label':'Playlist simple',
  }
];