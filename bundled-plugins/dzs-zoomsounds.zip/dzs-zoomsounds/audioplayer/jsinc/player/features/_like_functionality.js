

/**
 *
 * @param {DzsAudioPlayer} selfClass
 * @param {jQuery} $
 */
export const dzsap_likeFunctionalityInit = (selfClass, $) => {

  //
  // selfClass.cthis.off('click', '.btn-like');
  // selfClass.cthis.on('click', '.btn-like', handleClickLike);
  //
  // function handleClickLike() {
  //   var _t = $(this);
  //   if (selfClass.cthis.has(_t).length === 0) {
  //     return;
  //   }
  //
  //   if (_t.hasClass('active')) {
  //     (ajax_retract_like.bind(selfClass))();
  //   } else {
  //     (ajax_submit_like.bind(selfClass))();
  //   }
  // }

}

